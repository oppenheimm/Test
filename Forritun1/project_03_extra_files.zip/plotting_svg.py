
SIZE_X = 620
SIZE_Y = 520


def writeSVGPolyline(svgfile, waypoints, linecolor, strokewidth):
    print('<polyline points="', end='', file=svgfile)
    for point in waypoints:
        print(f'{point[0]},{point[1]} ', end='', file=svgfile  )
    print('"',file=svgfile)  
    print(f'style="fill:white;stroke:{linecolor};stroke-width:{strokewidth}"/>', file=svgfile)  

def writeSVGDot(svgfile, x, y, radius, dotcolor):
    print(f'<circle cx="{x}" cy="{y}" r="{radius}" stroke="{dotcolor}"', file=svgfile)
    print(f'stroke-width="1" fill="{dotcolor}"/>', file=svgfile)

def writeSVGCoastLine(svgfile, coastline_points):
    for points in coastline_points:
        writeSVGPolyline(svgfile, points, "blue", 1)

def writeSVGCities(svgfile, citylocations):
    for cityloc in citylocations:
        writeSVGDot(svgfile, cityloc[0], cityloc[1], 2, "red")

def drawTour(svgfile, tour, citylocations):
    tourlocations = []  
    for i in range(len(tour)):
        tourlocations.append( (citylocations[tour[i]][0], citylocations[tour[i]][1]) )
    tourlocations.append( (citylocations[tour[0]][0], citylocations[tour[0]][1]) )
    writeSVGPolyline(svgfile, tourlocations, "black", 2)

def writeSVGHeader(svgfile, sizex, sizey):
    print('<?xml version="1.0" standalone="no"?>', file=svgfile)
    print('<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN"', file=svgfile)
    print('"http://www.w3.org/Graphics/SGV/1.1/DTD/svg11.dtd">', file=svgfile)
    print(f'<svg width="{sizex}" height="{sizey}" xmlns="http://www.w3.org/2000/svg">', file=svgfile)

def writeSVGFooter(svgfile):
    print('</svg>',file=svgfile)

def get_coastline():
    coastline_file = open('us_coastline.txt','r')
    coastline_points = []

    line_segment = []
    for line in coastline_file:
        if line.startswith('NaN'):
            if len(line_segment) > 0:
                coastline_points.append( line_segment )
            line_segment = []
        else:
            x,y = [float(i) for i in line.split()]
            line_segment.append( (x,y) )
    coastline_file.close()
    return coastline_points

def get_city_locations():
    citylocation_file = open('us_city_locations.txt','r')

    citylocations = []
    for line in citylocation_file:
        x,y = [float(i) for i in line.split()]
        citylocations.append( (x,y) )
    citylocation_file.close()
    return citylocations

def get_tour():
    tour = []
    try:
        tour_file = open('solution.txt','r')
        tour = [int(i) for i in tour_file.readlines()]
        tour_file.close()
        return tour
    except:
        return None

def draw_svg(coastline_points, citylocations, tour):
    svgfile = open('travelling_salesman.svg','w')

    writeSVGHeader(svgfile, SIZE_X, SIZE_Y)
    writeSVGCoastLine(svgfile, coastline_points)
    writeSVGCities(svgfile, citylocations)
    if tour:
        drawTour(svgfile, tour, citylocations)
    writeSVGFooter(svgfile)

    svgfile.close()

coastline_points = get_coastline()
citylocations = get_city_locations()
tour = get_tour()

draw_svg(coastline_points, citylocations, tour)

