import matplotlib.pyplot as plt


def get_city_locations(filename):
    citylocation_file = open(filename,'r')
    citylocations = []
    for line in citylocation_file:
        x,y = [float(i) for i in line.split()]
        citylocations.append( (x, y) )
    citylocation_file.close()
    return citylocations

def get_tour(citylocations):
    try:
        destinations_file = open('solution.txt','r')
        destinations = [int(i) for i in destinations_file.readlines()]
        destinations_file.close()

        tour = []
        for i in range(len(destinations)):
            a = destinations[i-1]
            b = destinations[i]
            tour.append( ((citylocations[a][0], citylocations[b][0]),(citylocations[a][1], citylocations[b][1])) )
        return tour
    except:
        return None

filename = input('Locations filename: ')
problem_name = filename.rsplit('.',1)[0]

citylocations = get_city_locations(filename)
tour = get_tour(citylocations)

for x,y in citylocations:
    plt.plot(x,y, 'r.')

if tour:
    for start_point, end_point in tour:
        plt.plot( start_point, end_point, 'g-')

plt.savefig(f'{problem_name}.png')
plt.show()

