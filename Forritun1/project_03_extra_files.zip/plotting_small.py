import matplotlib.pyplot as plt


def get_city_locations():
    citylocation_file = open('small_locations.txt','r')
    citylocations = []
    for line in citylocation_file:
        x,y = [float(i) for i in line.split()]
        citylocations.append( (x, y) )
    citylocation_file.close()
    return citylocations

def get_tour(citylocations):
    try:
        destinations_file = open('solution.txt','r')
        destinations = [int(i) for i in destinations_file.readlines()]
        destinations_file.close()

        tour = []
        for i in range(len(destinations)):
            a = destinations[i-1]
            b = destinations[i]
            tour.append( ((citylocations[a][0], citylocations[b][0]),(citylocations[a][1], citylocations[b][1])) )
        return tour
    except:
        return None

citylocations = get_city_locations()
tour = get_tour(citylocations)

for x,y in citylocations:
    plt.plot(x,y, 'r.')

if tour:
    for start_point, end_point in tour:
        plt.plot( start_point, end_point, 'g-')

plt.savefig('small_problem.png')
plt.show()

