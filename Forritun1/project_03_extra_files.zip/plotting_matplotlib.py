import matplotlib.pyplot as plt

YMAX = 516.23

def get_coastline():
    coastline_file = open('us_coastline.txt','r')
    coastline_points = []

    x_coordinates = []
    y_coordinates = []
    for line in coastline_file:
        if line.startswith('NaN'):
            if len(x_coordinates) > 0:
                coastline_points.append( (x_coordinates, y_coordinates) )
            x_coordinates = []
            y_coordinates = []
        else:
            x,y = [float(i) for i in line.split()]
            x_coordinates.append(x)
            y_coordinates.append(YMAX-y)

    coastline_file.close()
    return coastline_points

def get_city_locations():
    citylocation_file = open('us_city_locations.txt','r')
    citylocations = []
    for line in citylocation_file:
        x,y = [float(i) for i in line.split()]
        citylocations.append( (x, YMAX - y) )
    citylocation_file.close()
    return citylocations

def get_tour(citylocations):
    try:
        destinations_file = open('solution.txt','r')
        destinations = [int(i) for i in destinations_file.readlines()]
        destinations_file.close()

        tour = []
        for i in range(len(destinations)):
            a = destinations[i-1]
            b = destinations[i]
            tour.append( ((citylocations[a][0], citylocations[b][0]),(citylocations[a][1], citylocations[b][1])) )
        return tour
    except:
        return None


coastline_points = get_coastline()
citylocations = get_city_locations()
tour = get_tour(citylocations)

for segment in coastline_points:
    plt.plot(segment[0], segment[1], 'b-', linewidth=1)

for x,y in citylocations:
    plt.plot(x,y, 'r.')

if tour:
    for start_point, end_point in tour:
        plt.plot( start_point, end_point, 'g-')

plt.savefig('travelling_salesman.pdf')
plt.show()

